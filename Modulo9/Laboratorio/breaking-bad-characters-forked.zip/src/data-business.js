import axios from "axios";

function getCharapters() {
  return axios
  .get("https://www.breakingbadapi.com/api/characters")
  .then(response => response.data);
}

export { getCharapters };