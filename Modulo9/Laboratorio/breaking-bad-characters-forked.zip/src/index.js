import "./styles.css";

import * as DataBusiness from "./data-business.js";
import * as Utils from "./utils.js";

DataBusiness.getCharapters().then(data => {
  const nodes = [];
  for (let charapter of data) {
  const node = Utils.createCharacterRow(charapter);
  node.onclick = function (){ 
    Utils.showCharacter(charapter)
  }
  nodes.push(node);
  }
  for (let node of nodes) {
  document.getElementById("root").append(node);
  }
 });

